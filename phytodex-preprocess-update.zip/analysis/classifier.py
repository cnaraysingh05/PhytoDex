"""Ask Gemini to inspect a plant photo. This replaces the proposed TFLite model.

Gemini's assessment is an observation, not a trained classifier probability.

Image resize/crop/normalize now lives in analysis/preprocess.py -- this file
only handles the Gemini request/response. prepare_image is re-imported here
so existing callers (tests/test_gemini.py, anyone doing
`from analysis.classifier import prepare_image`) keep working unchanged.
"""
import json
import os

from analysis.preprocess import AnalysisError, prepare_image


class ConfigurationError(AnalysisError):
    """The server has no usable Gemini API key."""


PROMPT = """Inspect this image for a plant and visible leaf health concerns.
Return JSON with these keys only: plant_name, visible_signs, possible_causes,
health_rating, certainty, limitations. plant_name is a string or null.
visible_signs and possible_causes are arrays of short strings. health_rating is
one of healthy, attention, concerning, unknown. certainty is one of low,
medium, high and describes how well the visible evidence supports your answer;
it is NOT a numeric probability. limitations is a short string.
If there is no recognizable plant or the photo is unusable, use unknown,
empty arrays, and explain why. Distinguish what is visible from possible
causes. Do not infer soil moisture, nutrients, pests, or species with certainty
from a leaf photo alone. Do not provide a made-up percentage."""


def _generate(contents, client=None):
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if client is None:
        if not key or key == "your_key_here":
            raise ConfigurationError("Set GEMINI_API_KEY in .env on the server")
        from google import genai
        client = genai.Client(api_key=key)
    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        contents=contents,
        config={"response_mime_type": "application/json"},
    )
    if not response.text:
        raise AnalysisError("Gemini returned no analysis")
    try:
        result = json.loads(response.text)
    except (TypeError, ValueError) as exc:
        raise AnalysisError("Gemini returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise AnalysisError("Gemini returned an unexpected response")
    return result


def classify_leaf(image_bytes, client=None):
    """Return raw Gemini observations from a JPEG/PNG photo."""
    from google.genai import types

    data, mime_type = prepare_image(image_bytes)
    return _generate([PROMPT, types.Part.from_bytes(data=data, mime_type=mime_type)], client)

